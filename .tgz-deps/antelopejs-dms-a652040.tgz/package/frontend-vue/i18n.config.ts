export default {
  fallbackLocale: "en",
};
